//
//  YZHSyncTaskManager.h
//  YZHURLSessionTaskOperation
//
//  Created by yuan on 2019/1/8.
//  Copyright © 2019年 yuan. All rights reserved.
//

#import "YZHTaskManager.h"

@interface YZHSyncTaskManager : YZHTaskManager



@end
