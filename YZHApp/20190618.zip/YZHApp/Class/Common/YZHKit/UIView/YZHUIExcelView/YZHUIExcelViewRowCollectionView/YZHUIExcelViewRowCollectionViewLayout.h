//
//  YZHUIExcelViewRowCollectionViewLayout.h
//  YZHApp
//
//  Created by yuan on 2017/7/17.
//  Copyright © 2017年 yuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZHUIExcelViewRowCollectionViewLayout : UICollectionViewLayout

@property (nonatomic, weak) id<UICollectionViewDelegateFlowLayout> delegate;

@end
