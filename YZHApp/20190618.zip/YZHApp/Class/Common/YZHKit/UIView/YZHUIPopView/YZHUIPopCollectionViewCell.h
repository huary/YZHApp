//
//  YZHUIPopCollectionViewCell.h
//  YZHUIPopViewDemo
//
//  Created by yuan on 2018/9/10.
//  Copyright © 2018年 yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YZHUIPopCellProtocol.h"

@interface YZHUIPopCollectionViewCell : UICollectionViewCell <YZHUIPopCellProtocol>

@end
