//
//  YZHUIPopTableViewCell.h
//  YZHUIPopViewDemo
//
//  Created by yuan on 2018/8/27.
//  Copyright © 2018年 yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YZHUIPopCellProtocol.h"

@interface YZHUIPopTableViewCell : UITableViewCell <YZHUIPopCellProtocol>

@end
