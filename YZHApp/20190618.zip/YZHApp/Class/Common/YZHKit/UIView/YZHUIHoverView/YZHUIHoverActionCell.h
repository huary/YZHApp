//
//  YZHUIHoverActionCell.h
//  YZHUIHoverViewDemo
//
//  Created by yuan on 2017/9/7.
//  Copyright © 2017年 yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YZHUIHoverView.h"

@interface YZHUIHoverActionCell : UICollectionViewCell

@property (nonatomic, strong) YZHHoverActionModel *actionModel;


@end
