//
//  NSObject+YZHRefreshView.m
//  contact
//
//  Created by yuan on 2018/12/6.
//  Copyright © 2018年 gdtech. All rights reserved.
//

#import "NSObject+YZHRefreshView.h"
#import <objc/runtime.h>


@implementation NSObject (YZHRefreshView)


-(void)setHz_bindRefreshViewTable:(NSMapTable<id,UIView<YZHUIRefreshViewProtocol> *> *)hz_bindRefreshViewTable
{
    objc_setAssociatedObject(self, @selector(hz_bindRefreshViewTable), hz_bindRefreshViewTable, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

-(NSMapTable<id,UIView<YZHUIRefreshViewProtocol>*> *)hz_bindRefreshViewTable
{
    NSMapTable *table =  objc_getAssociatedObject(self, _cmd);
    if (table == nil) {
        table = [NSMapTable mapTableWithKeyOptions:NSPointerFunctionsStrongMemory valueOptions:NSPointerFunctionsWeakMemory];
        self.hz_bindRefreshViewTable = table;
    }
    return table;
}

-(void)setRegisterViewTable:(NSMapTable<id,UIView *> *)registerViewTable
{
    objc_setAssociatedObject(self, @selector(setRegisterViewTable:), registerViewTable, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

-(NSMapTable<id, UIView *>*)registerViewTable
{
    NSMapTable *table = objc_getAssociatedObject(self, _cmd);
    if (table == nil) {
        table = [NSMapTable mapTableWithKeyOptions:NSPointerFunctionsStrongMemory valueOptions:NSPointerFunctionsWeakMemory];
        self.registerViewTable = table;
    }
    return table;
}

-(YZHUIRefreshConditionBlock)_defaultConditionBlock
{
    YZHUIRefreshConditionBlock condition = ^BOOL(UIView<YZHUIRefreshViewProtocol> *refreshView, id model) {
        if (refreshView.refreshModel == nil || refreshView.refreshModel == model) {
            return YES;
        }
        return NO;
    };
    return condition;
}


-(void)hz_addRefreshView:(UIView<YZHUIRefreshViewProtocol>*)refreshView forKey:(id)key
{
    [self.hz_bindRefreshViewTable setObject:refreshView forKey:key];
}

//刷新所有绑定的view
-(BOOL)hz_refresh
{
    return [self hz_refresh:nil];
}

//根据刷新条件刷新所有绑定的view
-(BOOL)hz_refresh:(YZHUIRefreshConditionBlock)condition
{
    NSEnumerator *valueEnumerator = self.hz_bindRefreshViewTable.objectEnumerator;
    UIView<YZHUIRefreshViewProtocol> *refreshView = nil;
    while (refreshView = [valueEnumerator nextObject]) {
        [self hz_refreshView:refreshView condition:condition];
    }
    return YES;
}


//根据绑定的Key对view进行刷新
-(BOOL)hz_refreshViewWithKey:(id)key
{
    UIView<YZHUIRefreshViewProtocol> *refreshView = [self.hz_bindRefreshViewTable objectForKey:key];
    return [self hz_refreshView:refreshView];
}

//通过指定View镜像刷新
-(BOOL)hz_refreshView:(UIView<YZHUIRefreshViewProtocol>*)refreshView
{
    return [self hz_refreshView:refreshView condition:nil];
}

//根据条件，对绑定的Key对view进行刷新
-(BOOL)hz_refreshViewWithKey:(id)key condition:(YZHUIRefreshConditionBlock)condition
{
    UIView<YZHUIRefreshViewProtocol> *refreshView = [self.hz_bindRefreshViewTable objectForKey:key];
    return [self hz_refreshView:refreshView condition:condition];
}

//根据条件，对view进行刷新
-(BOOL)hz_refreshView:(UIView<YZHUIRefreshViewProtocol>*)refreshView condition:(YZHUIRefreshConditionBlock)condition
{
    if (refreshView == nil) {
        return NO;
    }
    BOOL r = NO;

    if (!condition) {
        condition = [self _defaultConditionBlock];
    }
    r = condition(refreshView, self);

    if (r) {
        if ([refreshView respondsToSelector:@selector(refreshViewWithModel:)]) {
            r = [refreshView refreshViewWithModel:self];
        }
        else if (refreshView.refreshBlock) {
            r = refreshView.refreshBlock(refreshView, self);
        }
    }
    return r;
}

-(UIView<YZHUIRefreshViewProtocol>*)hz_refreshViewForKey:(id)key
{
    return [self.hz_bindRefreshViewTable objectForKey:key];
}

-(NSArray<UIView<YZHUIRefreshViewProtocol>*>*)hz_allRefreshView
{
    NSMutableArray<UIView<YZHUIRefreshViewProtocol> *> *refreshViewList = [NSMutableArray array];
    NSEnumerator *valueEnumerator = self.hz_bindRefreshViewTable.objectEnumerator;
    UIView<YZHUIRefreshViewProtocol> *refreshView = nil;
    while (refreshView = [valueEnumerator nextObject]) {
        [refreshViewList addObject:refreshView];
    }
    return [refreshViewList copy];
}

-(void)hz_clearRefreshView:(UIView<YZHUIRefreshViewProtocol>*)refreshView
{
    NSEnumerator *keyEnumerator = self.hz_bindRefreshViewTable.keyEnumerator;
    id key = nil;
    while (key = [keyEnumerator nextObject]) {
        UIView<YZHUIRefreshViewProtocol> *refreshViewTmp = [self.hz_bindRefreshViewTable objectForKey:key];
        if (refreshViewTmp == refreshView) {
            break;
        }
    }
    [self.hz_bindRefreshViewTable removeObjectForKey:key];
}

-(void)hz_clearRefreshViewForKey:(id)key
{
    [self.hz_bindRefreshViewTable removeObjectForKey:key];
}

-(void)hz_clearAllRefreshView
{
    [self.hz_bindRefreshViewTable removeAllObjects];
}


/*
 *这里是通过注册View,
 *有这个方法的原因是因为view绑定的model（弱应用）已经释放，而需要刷新这个view的模型是通过某一个Id（key）
 *来进行的，就可以通过那个id（key）找到对应刷新view，然后进行刷新。
 */
-(void)hz_registerView:(UIView*)view ForRegisterKey:(id)registerKey
{
    [self.registerViewTable setObject:view forKey:registerKey];
}

//通过在View中进行registerRefreshViewForRegisterKey来注册的view时的registerKey找到对应的
-(UIView*)hz_viewForRegisterKey:(id)registerKey
{
    return [self.registerViewTable objectForKey:registerKey];
}

//清除某一个注册的key
-(void)hz_clearRegisterViewForRegisterKey:(id)registerKey
{
    [self.registerViewTable removeObjectForKey:registerKey];
}

//清除所有的注册的view
-(void)hz_clearRegisterView
{
    [self.registerViewTable removeAllObjects];
}
@end
