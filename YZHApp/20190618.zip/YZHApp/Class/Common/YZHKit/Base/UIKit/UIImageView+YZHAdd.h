//
//  UIImageView+YZHAdd.h
//  YZHApp
//
//  Created by yuan on 2018/12/29.
//  Copyright © 2018年 yuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (YZHAdd)

-(CGSize)contentImageSize;


@end
