//
//  YZHBaseModalUIViewController.h
//  YXX
//
//  Created by yuan on 2017/5/4.
//  Copyright © 2017年 gdtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZHBaseModalUIViewController : UIViewController

@end
