//
//  YZHBaseModalUIViewController.m
//  YXX
//
//  Created by yuan on 2017/5/4.
//  Copyright © 2017年 gdtech. All rights reserved.
//

#import "YZHBaseModalUIViewController.h"

@interface YZHBaseModalUIViewController ()

@end

@implementation YZHBaseModalUIViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
