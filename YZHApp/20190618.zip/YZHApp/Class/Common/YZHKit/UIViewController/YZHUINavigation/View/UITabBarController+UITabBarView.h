//
//  UITabBarController+UITabBarView.h
//  YZHUINavigationController
//
//  Created by yuan on 2018/6/14.
//  Copyright © 2018年 dlodlo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBarController (UITabBarView)

/** 注释 */
@property (nonatomic, strong) UIView *tabBarView;


@end
