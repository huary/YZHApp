//
//  UIView+Snapshot.h
//  YZHUINavigationController
//
//  Created by yuan on 2018/6/14.
//  Copyright © 2018年 dlodlo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Snapshot)

-(UIImage*)snapshotImage;

-(UIImageView*)snapshotImageView;

@end
