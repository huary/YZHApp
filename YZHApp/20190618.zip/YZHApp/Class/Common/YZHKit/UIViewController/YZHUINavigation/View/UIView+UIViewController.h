//
//  UIView+UIViewController.h
//  BaseDefaultUINavigationController
//
//  Created by captain on 16/11/15.
//  Copyright (c) 2016年 yzh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (UIViewController)

-(UIViewController*)viewController;

//-(UINavigationController*)navigationController;
@end
