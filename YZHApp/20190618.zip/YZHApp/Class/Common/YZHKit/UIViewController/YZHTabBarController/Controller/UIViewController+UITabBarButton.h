//
//  UIViewController+UITabBarButton.h
//  YZHUINavigationController
//
//  Created by yuan on 2018/4/25.
//  Copyright © 2018年 dlodlo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YZHUITabBarButton.h"

@interface UIViewController (UITabBarButton)

@property (nonatomic, strong) YZHUITabBarButton *tabBarButton;

@end
